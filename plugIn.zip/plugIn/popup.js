document.getElementById('fetchData').addEventListener('click', function() {
  fetch('http://localhost:5000/api/data')
   .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.json();
    })
   .then(data => {
      if (data && data.message) {
        document.getElementById('response').innerText = data.message;
      } else {
        console.error('Invalid response data');
      }
    })
   .catch(error => console.error('Error:', error));
});